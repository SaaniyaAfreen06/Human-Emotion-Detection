# EEG_ICA
- ### This is the directory saving all EEG data after removing ocular movement effect by ICA
