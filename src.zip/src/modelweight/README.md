# ModelWeight
- ### This is the directory saving all model weights for autoencoder or classifier
